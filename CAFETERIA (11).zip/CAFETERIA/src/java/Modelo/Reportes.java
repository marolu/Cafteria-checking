
package Modelo;

public class Reportes {
    int id_ped, cant_tot,tot_ven,cant_ped,tot_pro;
    double totped, ingresos;
    String fecped;
    
    public Reportes() {
    } 

    public Reportes(int id_ped, int cant_tot, int tot_ven, int cant_ped, int tot_pro, double totped, String fecped, double ingresos) {
        this.id_ped = id_ped;
        this.cant_tot = cant_tot;
        this.tot_ven = tot_ven;
        this.cant_ped = cant_ped;
        this.tot_pro = tot_pro;
        this.totped = totped;
        this.fecped = fecped;
        this.ingresos=ingresos;
    }

    public double getIngresos() {
        return ingresos;
    }

    public void setIngresos(double ingresos) {
        this.ingresos = ingresos;
    }
  
    public int getTot_ven() {
        return tot_ven;
    }

    public void setTot_ven(int tot_ven) {
        this.tot_ven = tot_ven;
    }

    public int getCant_ped() {
        return cant_ped;
    }

    public void setCant_ped(int cant_ped) {
        this.cant_ped = cant_ped;
    }

    public int getTot_pro() {
        return tot_pro;
    }

    public void setTot_pro(int tot_pro) {
        this.tot_pro = tot_pro;
    }
    

    public int getCant_tot() {
        return cant_tot;
    }

    public void setCant_tot(int cant_tot) {
        this.cant_tot = cant_tot;
    }

    public int getId_ped() {
        return id_ped;
    }

    public void setId_ped(int id_ped) {
        this.id_ped = id_ped;
    }

    public double getTotped() {
        return totped;
    }

    public void setTotped(double totped) {
        this.totped = totped;
    }

    public String getFecped() {
        return fecped;
    }

    public void setFecped(String fecped) {
        this.fecped = fecped;
    }
    
}
