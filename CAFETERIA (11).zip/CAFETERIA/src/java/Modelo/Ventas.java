
package Modelo;

public class Ventas {
    
    int id,idemp;
    float precio;
    String fecha, cliente,comentario, nombemp;
    int Idemp;
    int codped, codprod,cant;
    double preuni, sbto;

    public Ventas() {
    }

    public Ventas(int id, int idemp, float precio, String fecha, String cliente, String comentario, String nombemp, int Idemp, int codped, int codprod, int cant, double preuni, double sbto) {
        this.id = id;
        this.idemp = idemp;
        this.precio = precio;
        this.fecha = fecha;
        this.cliente = cliente;
        this.comentario = comentario;
        this.nombemp = nombemp;
        this.Idemp = Idemp;
        this.codped = codped;
        this.codprod = codprod;
        this.cant = cant;
        this.preuni = preuni;
        this.sbto = sbto;
    }

    public int getCodped() {
        return codped;
    }

    public void setCodped(int codped) {
        this.codped = codped;
    }

    public int getCodprod() {
        return codprod;
    }

    public void setCodprod(int codprod) {
        this.codprod = codprod;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public double getPreuni() {
        return preuni;
    }

    public void setPreuni(double preuni) {
        this.preuni = preuni;
    }

    public double getSbto() {
        return sbto;
    }

    public void setSbto(double sbto) {
        this.sbto = sbto;
    }

    

    

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdemp() {
        return idemp;
    }

    public void setIdemp(int idemp) {
        this.idemp = idemp;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getNombemp() {
        return nombemp;
    }

    public void setNombemp(String nombemp) {
        this.nombemp = nombemp;
    }
    
    
}
