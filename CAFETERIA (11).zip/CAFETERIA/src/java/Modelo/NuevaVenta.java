package Modelo;

public class NuevaVenta {
    int cod_prod;
    int cod_cateprod;
    String descripcion;
    double precio, subti;
    String nombre;
    int stock;
    String fecha_fab;
    String fecha_exp;
    int cod_proveedor;
    String nom_cat;
    int cod_tipoproveedor;
    int cantidadT;
    String comenVen, fecha;
    int cod_ped;
    String clit;
    double Precioto;
    String fechped;
    int Idemp;

    public NuevaVenta(int cod_prod, int cod_cateprod, String descripcion, double precio, double subti, String nombre, int stock, String fecha_fab, String fecha_exp, int cod_proveedor, String nom_cat, int cod_tipoproveedor, int cantidadT, String comenVen, String fecha, int cod_ped, String clit, double Precioto, String fechped, int Idemp) {
        this.cod_prod = cod_prod;
        this.cod_cateprod = cod_cateprod;
        this.descripcion = descripcion;
        this.precio = precio;
        this.subti = subti;
        this.nombre = nombre;
        this.stock = stock;
        this.fecha_fab = fecha_fab;
        this.fecha_exp = fecha_exp;
        this.cod_proveedor = cod_proveedor;
        this.nom_cat = nom_cat;
        this.cod_tipoproveedor = cod_tipoproveedor;
        this.cantidadT = cantidadT;
        this.comenVen = comenVen;
        this.fecha = fecha;
        this.cod_ped = cod_ped;
        this.clit = clit;
        this.Precioto = Precioto;
        this.fechped = fechped;
        this.Idemp = Idemp;
    }

    public String getClit() {
        return clit;
    }

    public void setClit(String clit) {
        this.clit = clit;
    }

    public double getPrecioto() {
        return Precioto;
    }

    public void setPrecioto(double Precioto) {
        this.Precioto = Precioto;
    }

    public String getFechped() {
        return fechped;
    }

    public void setFechped(String fechped) {
        this.fechped = fechped;
    }

    public int getIdemp() {
        return Idemp;
    }

    public void setIdemp(int Idemp) {
        this.Idemp = Idemp;
    }

    
    
    
    

    public int getCod_ped() {
        return cod_ped;
    }

    public void setCod_ped(int cod_ped) {
        this.cod_ped = cod_ped;
    }
    
    
    
    public double getSubti() {
        return subti;
    }

    public void setSubti(double subti) {
        this.subti = subti;
    }
    
    public NuevaVenta() {
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public String getComenVen() {
        return comenVen;
    }

    public void setComenVen(String comenVen) {
        this.comenVen = comenVen;
    }

    public int getCantidadT() {
        return cantidadT;
    }

    public void setCantidadT(int cantidadT) {
        this.cantidadT = cantidadT;
    }

    public NuevaVenta(double subti, String comenVen,String fecha, int cod_prod, int cod_cateprod, String descripcion, double precio, String nombre, int stock, String fecha_fab, String fecha_exp, int cod_proveedor, String nom_cat, int cod_tipoproveedor, int cantidadT) {
        this.cod_prod = cod_prod;
        this.cod_cateprod = cod_cateprod;
        this.descripcion = descripcion;
        this.precio = precio;
        this.nombre = nombre;
        this.stock = stock;
        this.fecha_fab = fecha_fab;
        this.fecha_exp = fecha_exp;
        this.cod_proveedor = cod_proveedor;
        this.nom_cat = nom_cat;
        this.cod_tipoproveedor = cod_tipoproveedor;
        this.cantidadT = cantidadT;
    }

    public int getCod_prod() {
        return cod_prod;
    }

    public void setCod_prod(int cod_prod) {
        this.cod_prod = cod_prod;
    }

    public int getCod_cateprod() {
        return cod_cateprod;
    }

    public void setCod_cateprod(int cod_cateprod) {
        this.cod_cateprod = cod_cateprod;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getFecha_fab() {
        return fecha_fab;
    }

    public void setFecha_fab(String fecha_fab) {
        this.fecha_fab = fecha_fab;
    }

    public String getFecha_exp() {
        return fecha_exp;
    }

    public void setFecha_exp(String fecha_exp) {
        this.fecha_exp = fecha_exp;
    }

    public int getCod_proveedor() {
        return cod_proveedor;
    }

    public void setCod_proveedor(int cod_proveedor) {
        this.cod_proveedor = cod_proveedor;
    }

    public String getNom_cat() {
        return nom_cat;
    }

    public void setNom_cat(String nom_cat) {
        this.nom_cat = nom_cat;
    }

    public int getCod_tipoproveedor() {
        return cod_tipoproveedor;
    }

    public void setCod_tipoproveedor(int cod_tipoproveedor) {
        this.cod_tipoproveedor = cod_tipoproveedor;
    }
    
    
}