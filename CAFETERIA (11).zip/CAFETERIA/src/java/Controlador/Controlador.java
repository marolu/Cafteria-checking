package Controlador;

import Config.Conexion;
import Modelo.Inventario;
import Modelo.MostrarUsuario;
import Modelo.NuevaVenta;
import Modelo.Pedidos;
import Modelo.Principal;
import Modelo.Producto;
import Modelo.Reportes;
import Modelo.Ventas;
import ModeloDAO.InventarioDAO;
import ModeloDAO.MostrarUsuarioDAO;
import ModeloDAO.NuevaVentaDAO;
import ModeloDAO.PedidosDAO;
import ModeloDAO.PrincipalDAO;
import ModeloDAO.ProductoDAO;
import ModeloDAO.ReportesDAO;
import ModeloDAO.VentasDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Controlador extends HttpServlet {

    String listar = "vistas/ventas.jsp";
    String listarpr = "vistas/principal.jsp";
    String listarprod = "vistas/editar-carta.jsp";
    String listarinv = "vistas/inventario.jsp";
    String listped = "vistas/reportes.jsp";
    String listarNuev = "vistas/nueva-venta.jsp";
    String listarusr = "vistas/config.jsp";
    String listartotalv="vistas/ver-total-ventas.jsp";
    String addregistro = "vistas/inventario-agregarproducto.jsp";
    
    VentasDAO vtdao = new VentasDAO();
    Ventas vt = new Ventas();
    PrincipalDAO prdao = new PrincipalDAO();
    Principal pr = new Principal();
    Producto p = new Producto();
    ProductoDAO pdao = new ProductoDAO();
    InventarioDAO invdao = new InventarioDAO();
    Inventario inv = new Inventario();
    PedidosDAO peddao = new PedidosDAO();
    Pedidos ped = new Pedidos();
    NuevaVentaDAO nvtdao = new NuevaVentaDAO();
    NuevaVenta nvt = new NuevaVenta();
    MostrarUsuario mu = new MostrarUsuario();
    MostrarUsuarioDAO mudao = new MostrarUsuarioDAO();
    ReportesDAO reddao=new ReportesDAO();
    Reportes re =new Reportes();
    int id;

    List<NuevaVenta> productos = new ArrayList<>();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String acceso = "";
        String action = request.getParameter("accion");

        if (action == null) {
            acceso = listar; // Acción por defecto si no se proporciona ninguna
        } else if (action.equalsIgnoreCase("listar")) {
            acceso = listar; // Acción para listar las ventas
        } else if (action.equalsIgnoreCase("listarprod")) { 
            acceso = listarprod;
        } else if (action.equalsIgnoreCase("listarpr")) {
            // Lógica para listar los productos principales
            List<Principal> listaProductos = prdao.listarpr(); // Obtener lista de productos más vendidos
            request.setAttribute("productosPrincipales", listaProductos);

            // Obtener estadísticas desde el DAO y pasarlas al JSP
            pr = prdao.obtenerEstadisticas(); // Método para obtener estadísticas como número de usuarios, productos, etc.
            request.setAttribute("numUsuarios", pr.getNumUsuarios());
            request.setAttribute("numCategorias", pr.getNumCategorias());
            request.setAttribute("numProductos", pr.getNumProductos());
            request.setAttribute("ventasDelDia", pr.getVentasDelDia());
            request.setAttribute("numVentasTotal", pr.getNumVentasTotal());
            
            acceso = listarpr; // Redirigir a principal.jsp con los datos
        } else if (action.equalsIgnoreCase("listarinv")) {
            // Lógica para listar los productos del inventario
            List<Inventario> listarinven = invdao.listarinv(); // Obtener lista de productos más vendidos
            request.setAttribute("productosInventario", listarinven);
            
            inv = invdao.datosInventario();
            request.setAttribute("valor_invent", inv.getValor_invent());
            request.setAttribute("cant_prov", inv.getCant_prov());
            request.setAttribute("stock_invent", inv.getStock_invent());
            
            acceso = listarinv;
        } else if (action.equalsIgnoreCase("listped")) {
            List<Reportes> listaPedidos = reddao.listped(); // Obtener lista de productos más vendidos
            request.setAttribute("totalPedidos", listaPedidos);
            
            re = reddao.datosPedidos();
            request.setAttribute("tot_ven", re.getTot_ven());
            request.setAttribute("cant_ped", re.getCant_ped());
            request.setAttribute("tot_pro", re.getTot_pro());
            
            List<Reportes> grafica1 = reddao.graf1(); // Obtener lista de productos más vendidos
            request.setAttribute("inegresosPed", grafica1);
            
            List<Reportes> grafica2 = reddao.graf2(); // Obtener lista de productos más vendidos
            request.setAttribute("cantxcate", grafica2);
            
            List<Reportes> grafica3 = reddao.graf3(); // Obtener lista de productos más vendidos
            request.setAttribute("top5xsem", grafica3);
            
            List<Reportes> grafica4p1 = reddao.graf4p1(); // Obtener lista de productos más vendidos
            request.setAttribute("comp2023", grafica4p1);
            
            List<Reportes> grafica4p2 = reddao.graf4p2(); // Obtener lista de productos más vendidos
            request.setAttribute("comp2024", grafica4p2);

            acceso=listped;
        } else if (action.equalsIgnoreCase("listarNuev")) {
            acceso = listarNuev; // Redirigir a la página nueva-venta.jsp

            String acc = request.getParameter("btnselec");
            if (acc != null) {
                switch (acc) {
                    case "1":
                    case "2":
                    case "4":
                    case "5":
                    case "6":
                    case "7": {
                        int codCatePro = Integer.parseInt(acc);
                        List<NuevaVenta> lista = nvtdao.listarNuev(codCatePro);
                        request.setAttribute("productos", lista);
                        request.getRequestDispatcher("vistasdeventa/listarproductos.jsp").forward(request, response);
                        return; // Salir para evitar redirigir dos veces
                    }
                    case "8": {
                        List<NuevaVenta> lista = nvtdao.listarNuev();
                        request.setAttribute("productos", lista);
                        request.getRequestDispatcher("vistasdeventa/listarproductos.jsp").forward(request, response);
                        return; // Salir para evitar redirigir dos veces
                    }
                    default:
                        acceso = listarNuev; // Mantener acceso a nueva-venta.jsp si no hay coincidencia
                        break;
                }
            }
        }else if (action.equalsIgnoreCase("listarusr")){
            acceso=listarusr;
        }else if(action.equalsIgnoreCase("eliminar")){
            id=Integer.parseInt(request.getParameter("id"));
            inv.setId_produc(id);
            invdao.eliminar(id);
            
            inv = invdao.datosInventario();
            request.setAttribute("valor_invent", inv.getValor_invent());
            request.setAttribute("cant_prov", inv.getCant_prov());
            request.setAttribute("stock_invent", inv.getStock_invent());
            
            acceso=listarinv;
        }else if (action.equalsIgnoreCase("listartotalv")){
            acceso=listartotalv;
        }else if (action.equalsIgnoreCase("addregistro")) {
            acceso = addregistro;
        } else if (action.equalsIgnoreCase("agregar")) {
            List<Inventario> listarinven = invdao.listarinv();
            List<Producto> listarproductos = pdao.listar();// Obtener lista de productos más vendidos
            request.setAttribute("productosInventario", listarinven);
            request.setAttribute("productosInventario", listarproductos);

            inv = invdao.datosInventario();
            request.setAttribute("valor_invent", inv.getValor_invent());
            request.setAttribute("cant_prov", inv.getCant_prov());
            request.setAttribute("stock_invent", inv.getStock_invent());

            String cod_cateprod = request.getParameter("txtCategoria");
            String descripcion = request.getParameter("txtDescripcion");
            String precio = request.getParameter("txtPrecio");
            String nombre = request.getParameter("txtNombre");
            String stock = request.getParameter("txtStockDisponible");
            String fecha_fab = request.getParameter("txtFechFabricacion");
            String fecha_exp = request.getParameter("txtFechaVencimiento");
            String cod_proveedor = request.getParameter("txtCodigoProveedor");
            String cod_tipoprod = request.getParameter("txtTipoProducto");

            p.setCod_cateprod(Integer.parseInt(cod_cateprod));
            p.setDescripcion(descripcion);
            p.setPrecio(Double.parseDouble(precio));
            p.setNombre(nombre);
            p.setStock(Integer.parseInt(stock));
            p.setFecha_fab(fecha_fab);
            p.setFecha_exp(fecha_exp);
            p.setCod_proveedor(Integer.parseInt(cod_proveedor));
            p.setCod_tipoprod(Integer.parseInt(cod_tipoprod));
            pdao.add(p);

            acceso = listarinv;

            // Acción para listar las ventas
        } else if (action.equalsIgnoreCase("buscarProducto")) {
            int codip = Integer.parseInt(request.getParameter("codigoproducto"));
            p = pdao.listarId(codip);
            request.setAttribute("producto", p);
            acceso = listarNuev;
        }else if (action.equalsIgnoreCase("AgregarProducto") || action.equalsIgnoreCase("EliminarProducto")) {
            HttpSession session = request.getSession();
            List<NuevaVenta> productos = (List<NuevaVenta>) session.getAttribute("listaPe");

            if (productos == null) {
                productos = new ArrayList<>();
            }

            if (action.equalsIgnoreCase("AgregarProducto")) {
                // Capturar los datos del producto
                int codPro = Integer.parseInt(request.getParameter("codproducto"));
                String nomPro = request.getParameter("nombreproducto");
                double precioP = Double.parseDouble(request.getParameter("precioP"));
                int cantPV = Integer.parseInt(request.getParameter("cantidadP"));
                double subTot = precioP * cantPV;

                // Crear un nuevo objeto del producto
                NuevaVenta nuevoProducto = new NuevaVenta();
                nuevoProducto.setCod_prod(codPro);
                nuevoProducto.setNombre(nomPro);
                nuevoProducto.setPrecio(precioP);
                nuevoProducto.setCantidadT(cantPV);
                nuevoProducto.setSubti(subTot);

                // Añadir el producto a la lista
                productos.add(nuevoProducto);
            } else if (action.equalsIgnoreCase("EliminarProducto")) {
                int codigo = Integer.parseInt(request.getParameter("id"));

                if (productos != null) {
                    productos.removeIf(p -> p.getCod_prod() == codigo);
                }
            }

            // Calcular el total
            double total = productos.stream()
                    .mapToDouble(NuevaVenta::getSubti)
                    .sum();

            // Actualizar la lista y total en la sesión
            session.setAttribute("listaPe", productos);
            session.setAttribute("total", total);  // Guardar el total en la sesión

            // Redirigir para evitar duplicados al actualizar
            response.sendRedirect("Controlador?accion=listarNuev");
            return;
        }else if (action.equals("CancelarOrden")) {
    // Obtener la sesión activa
    HttpSession session = request.getSession();
    
    // Recuperar la lista de productos de la sesión
    List<NuevaVenta> productos = (List<NuevaVenta>) session.getAttribute("listaPe");
    
    if (productos != null) {
        // Eliminar todos los productos de la lista
        productos.clear(); // Esta función elimina todos los elementos del ArrayList
    }
    double total =0;
    session.setAttribute("total", total);

    // Redirigir a la acción de listar productos (o a la página de inicio)
    acceso = listarNuev;  // O la página que desees mostrar después de cancelar
}else if (action.equalsIgnoreCase("FinalizarOrden")) {
    try {
        String cliente = request.getParameter("cliente");
        String totalParam = request.getParameter("total");
        String empleadoParam = request.getParameter("empleado");
        String comentario = request.getParameter("comentario");

        if (cliente == null || totalParam == null || empleadoParam == null) {
            throw new IllegalArgumentException("Parámetros obligatorios faltantes");
        }

        float total = Float.parseFloat(totalParam);
        int empleado = Integer.parseInt(empleadoParam);

        nvt.setIdemp(empleado);
        nvt.setFecha("GETDATE()");
        nvt.setPrecioto(total);
        nvt.setClit(cliente);
        nvt.setComenVen(comentario);

        nvtdao.guardarVenta(nvt);

        int idPedido = nvtdao.IdVentas();

        if (productos == null || productos.isEmpty()) {
            throw new IllegalArgumentException("La lista de productos está vacía o no inicializada");
        }

        for (NuevaVenta producto : productos) {
            NuevaVenta detalle = new NuevaVenta();
            detalle.setCod_ped(idPedido);
            detalle.setCod_prod(producto.getCod_prod());
            detalle.setCantidadT(producto.getCantidadT());
            detalle.setPrecio(producto.getPrecio());

            nvtdao.guardarDetalleventas(detalle);
        }

        if (!response.isCommitted()) {
            request.setAttribute("mensaje", "Orden finalizada correctamente");
            request.getRequestDispatcher("paginaExito.jsp").forward(request, response);
        }

    } catch (NumberFormatException e) {
        e.printStackTrace();
        if (!response.isCommitted()) {
            request.setAttribute("error", "Error en el formato de los datos enviados");
            request.getRequestDispatcher("paginaError.jsp").forward(request, response);
        }

    } catch (IllegalArgumentException e) {
        e.printStackTrace();
        if (!response.isCommitted()) {
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("paginaError.jsp").forward(request, response);
        }

    } catch (Exception e) {
        e.printStackTrace();
        if (!response.isCommitted()) {
            request.setAttribute("error", "Ha ocurrido un error inesperado: " + e.getMessage());
            request.getRequestDispatcher("paginaError.jsp").forward(request, response);
        }
    }
    acceso = listarNuev;
}

        // Redirigir al JSP correspondiente
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}