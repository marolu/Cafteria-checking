
package ModeloDAO;

import Config.Conexion;
import java.sql.*;
import java.util.*;
import Modelo.MostrarUsuario;

public class MostrarUsuarioDAO {
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Conexion conexion = new Conexion();
    
    public List<MostrarUsuario> listarusr() {
       ArrayList<MostrarUsuario> listarusr=new ArrayList<>();
       String sql= "Select us.*, em.Nombre as nombem, em.Rol as Rol from usuario us inner join empleado em on us.Cod_Usuario = em.Cod_Usuario ";
        try {
            con = conexion.getConexion(); // Obtiene la conexión
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                MostrarUsuario mu= new MostrarUsuario();
                mu.setId(rs.getInt("Cod_Usuario"));
                mu.setUsuario(rs.getString("Usuario"));
                mu.setContraseña(rs.getString("Contraseña"));
                mu.setNombus(rs.getString("nombem"));
                mu.setRol(rs.getString("Rol"));
                listarusr.add(mu);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return listarusr;
    }
}
