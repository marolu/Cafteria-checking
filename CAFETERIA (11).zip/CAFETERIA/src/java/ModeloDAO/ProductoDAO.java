
package ModeloDAO;
import Config.Conexion;
import Modelo.Producto;
import Interfaces.CRUD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Conexion conexion = new Conexion();
    
    public Producto listarId(int cod_prod){
        Producto pr= new Producto();
        String sql="select Cod_Producto, Nombre, Precio from producto where Cod_Producto="+cod_prod;
        try{
            con = conexion.getConexion(); // Obtiene la conexión
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                pr.setCod_prod(rs.getInt("Cod_Producto"));
                pr.setNombre(rs.getString("Nombre"));
                pr.setPrecio(rs.getDouble("Precio"));
            }
           
        } catch(Exception e){
            
        }
        return pr;
    }
    
    public List<Producto> listar() {  //  EXCEPCION, no se va a consumir pero es parte de método
        List<Producto> listar = new ArrayList<>();

        try {

            con = conexion.getConexion(); // Obtiene la conexión
            String sql = "Select * from producto";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Producto prod = new Producto();

                prod.setCod_prod(rs.getInt("Cod_Producto"));
                prod.setCod_cateprod(rs.getInt("Cod_catePro"));
                prod.setDescripcion(rs.getString("Descripcion"));
                prod.setPrecio(rs.getDouble("Precio"));
                prod.setNombre(rs.getString("Nombre"));
                prod.setStock(rs.getInt("stock"));
                prod.setFecha_fab(rs.getString("Fecha_fab"));
                prod.setFecha_exp(rs.getString("Fecha_exp"));
                prod.setCod_proveedor(rs.getInt("Cod_Proveedor"));
                prod.setCod_tipoprod(rs.getInt("Cod_Tipoprod"));

                listar.add(prod);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return listar;}
    
    
    
    
    public List<Producto> listarprod() {
        ArrayList<Producto> listarprod = new ArrayList<>();
        String sql = "Select p.*, cp.Descripcion as NomCat from producto p inner join categoria_pro cp on p.Cod_CatePro = cp.Cod_CatePro where p.Cod_Tipoprod = 2 order by p.Cod_Producto ASC";
        try {
            con = conexion.getConexion(); // Obtiene la conexión
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                Producto prod = new Producto();
                prod.setCod_prod(rs.getInt("Cod_Producto"));
                prod.setNom_cat(rs.getString("NomCat"));
                prod.setNombre(rs.getString("Nombre"));
                prod.setDescripcion(rs.getString("Descripcion"));
                prod.setStock(rs.getInt("stock"));
                prod.setPrecio(rs.getDouble("Precio"));
                listarprod.add(prod);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return listarprod;
    }
    
    public boolean add(Producto prod) {
        String sql = "INSERT INTO producto (Cod_Producto, Cod_CatePro, Descripcion, Precio, Nombre, stock, Fecha_fab, Fecha_exp, Cod_Proveedor, Cod_Tipoprod) "
                + "VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            con = conexion.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, prod.getCod_cateprod());
            ps.setString(2, prod.getDescripcion());
            ps.setDouble(3, prod.getPrecio());
            ps.setString(4, prod.getNombre());
            ps.setInt(5, prod.getStock());
            ps.setString(6, prod.getFecha_fab());
            ps.setString(7, prod.getFecha_exp());
            ps.setInt(8, prod.getCod_proveedor());
            ps.setInt(9, prod.getCod_tipoprod());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace(); // Imprime la excepción para depuración
        }
        return false;
    }
}
