/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ModeloDAO;

import Config.Conexion;
import Modelo.Reportes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lucer
 */
public class ReportesDAO {
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Conexion conexion = new Conexion();
    
    public Reportes datosPedidos() {
        Reportes ped = new Reportes();

        try {
            con = conexion.getConexion();

            String sqlTotalVentas = "SELECT SUM(total) AS tot_ven FROM pedido";
            ps = con.prepareStatement(sqlTotalVentas);
            rs = ps.executeQuery();
            if (rs.next()) {
                ped.setTot_ven(rs.getInt("tot_ven"));
            }
            
            String sqlCantidadPedidos = "Select COUNT(*) AS cant_ped FROM pedido";
            ps = con.prepareStatement(sqlCantidadPedidos);
            rs = ps.executeQuery();
            if (rs.next()) {
                ped.setCant_ped(rs.getInt("cant_ped"));
            }
            
            String sqlTotalProductos = "Select COUNT(*) AS tot_pro FROM producto";
            ps = con.prepareStatement(sqlTotalProductos);
            rs = ps.executeQuery();
            if (rs.next()) {
                ped.setTot_pro(rs.getInt("tot_pro"));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return ped; // Devolver el objeto Principal con las métricas
    }
    
    
    public List<Reportes> listped() {
        List<Reportes> listped = new ArrayList<>();
        try {
            con = conexion.getConexion(); // Obtener la conexión a la base de datos
            
            // Consulta para obtener los productos más vendidos
            String sql = "SELECT dp.Cod_Pedido, p.Fecha, p.Total,SUM(dp.Cantidad) AS cant_tot FROM pedido p "
                       + "INNER JOIN detalle_pedido dp ON p.Cod_Pedido =dp.Cod_Pedido "
                       +"GROUP BY(dp.Cod_Pedido)";
                       
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                // Crear un objeto Principal para cada producto más vendido
                Reportes ped = new Reportes();
                ped.setId_ped(rs.getInt("Cod_Pedido"));
                ped.setCant_tot(rs.getInt("cant_tot"));
                ped.setTotped(rs.getDouble("Total"));
                ped.setFecped(rs.getString("Fecha"));
                
                // Añadir el producto a la lista
                listped.add(ped);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return listped; // Devolver la lista de productos más vendidos
    }

    public List<Reportes> graf1() {
        List<Reportes> graf1 = new ArrayList<>();
        try {
            con = conexion.getConexion(); // Obtener la conexión a la base de datos
            
            // Consulta para obtener los productos más vendidos
            String sql = "select SUM(p.total) AS Total_Venta from pedido p where year(p.fecha)=2024 group by month(p.fecha)";
                       
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                // Crear un objeto Principal para cada producto más vendido
                Reportes graf = new Reportes();
                graf.setIngresos(rs.getInt("Total_Venta"));    
                // Añadir el producto a la lista
                graf1.add(graf);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return graf1;
    }
    
    public List<Reportes> graf2() {
        List<Reportes> graf2 = new ArrayList<>();
        try {
            con = conexion.getConexion(); // Obtener la conexión a la base de datos
            
            // Consulta para obtener los productos más vendidos
            String sql = "SELECT  c.descripcion, SUM(dp.cantidad) AS total_cantidad FROM  detalle_pedido dp JOIN  producto p ON dp.cod_producto = p.cod_producto JOIN  categoria_pro c ON p.cod_catepro = c.cod_catepro GROUP BY c.descripcion";
                       
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                // Crear un objeto Principal para cada producto más vendido
                Reportes graf = new Reportes();
                graf.setFecped(rs.getString("descripcion"));
                graf.setIngresos(rs.getInt("total_cantidad"));    
                // Añadir el producto a la lista
                graf2.add(graf);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return graf2;
    }
    
    
    public List<Reportes> graf3() {
        List<Reportes> graf3 = new ArrayList<>();
        try {
            con = conexion.getConexion(); // Obtener la conexión a la base de datos
            
            // Consulta para obtener los productos más vendidos
            String sql = "SELECT  p.nombre, SUM(dp.cantidad) AS total_cantidad  FROM detalle_pedido dp JOIN  pedido pe ON dp.cod_pedido = pe.cod_pedido JOIN " +
"    producto p ON dp.cod_producto = p.cod_producto WHERE YEARWEEK(pe.fecha, 1) = YEARWEEK(CURDATE(), 1) GROUP BY  dp.cod_producto, p.nombre ORDER BY total_cantidad DESC LIMIT 5;";

                       
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                // Crear un objeto Principal para cada producto más vendido
                Reportes graf = new Reportes();
                graf.setFecped(rs.getString("nombre"));
                graf.setIngresos(rs.getInt("total_cantidad"));    
                // Añadir el producto a la lista
                graf3.add(graf);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return graf3;
    }
    
    
    public List<Reportes> graf4p1() {
        List<Reportes> graf4p1 = new ArrayList<>();
        try {
            con = conexion.getConexion(); // Obtener la conexión a la base de datos

            // Consulta para obtener los productos más vendidos
            String sql = "SELECT MONTH(fecha) AS mes, COUNT(cod_pedido) AS total_pedidos FROM pedido WHERE YEAR(fecha) = 2023 GROUP BY MONTH(fecha) ORDER BY mes";

            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                // Crear un objeto Principal para cada producto más vendido
                Reportes graf = new Reportes();
                graf.setIngresos(rs.getInt("total_pedidos"));
                // Añadir el producto a la lista
                graf4p1.add(graf);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return graf4p1;
    }
    
    public List<Reportes> graf4p2() {
        List<Reportes> graf4p2 = new ArrayList<>();
        try {
            con = conexion.getConexion(); // Obtener la conexión a la base de datos

            // Consulta para obtener los productos más vendidos
            String sql = "SELECT MONTH(fecha) AS mes, COUNT(cod_pedido) AS total_pedidos FROM pedido WHERE YEAR(fecha) = 2024 GROUP BY MONTH(fecha) ORDER BY mes";

            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                // Crear un objeto Principal para cada producto más vendido
                Reportes graf = new Reportes();
                graf.setIngresos(rs.getInt("total_pedidos"));
                // Añadir el producto a la lista
                graf4p2.add(graf);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar los recursos para evitar fugas de memoria
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return graf4p2;
    }
}
