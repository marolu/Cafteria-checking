package ModeloDAO;

import Config.Conexion;
import Modelo.NuevaVenta;
import Modelo.Ventas;
import java.sql.*;
import java.util.*;

public class NuevaVentaDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int a;
    
    public List<NuevaVenta> listarNuev(int codCatePro) {
        List<NuevaVenta> listanvt = new ArrayList<>();
        String sql = "SELECT Cod_Producto, precio, nombre FROM producto WHERE Cod_Tipoprod=2 and Cod_catePro = ?";

        try {
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, codCatePro);
            rs = ps.executeQuery();
            while (rs.next()) {
                NuevaVenta nvt = new NuevaVenta();
                nvt.setCod_prod(rs.getInt("Cod_Producto"));
                nvt.setPrecio(rs.getDouble("precio"));
                nvt.setNombre(rs.getString("nombre"));
                listanvt.add(nvt);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listanvt;
    }
 



    public List listarNuev() {
        ArrayList<NuevaVenta>listnvt=new ArrayList<>();
       String sql= "select * from producto";
        try {
            con=cn.getConexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                NuevaVenta nv= new NuevaVenta();
                nv.setCod_prod(rs.getInt("cod_Producto"));
                nv.setNombre(rs.getString("nombre"));
                nv.setPrecio(rs.getDouble("precio"));
                listnvt.add(nv);
            }
  
        } catch (Exception e) {
     
        }
        return listnvt;
    }
    
    public List listarasd() {
        ArrayList<NuevaVenta>listarasd=new ArrayList<>();
       String sql= "select * from producto";
        try {
            con=cn.getConexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                NuevaVenta nv= new NuevaVenta();
                nv.setCod_prod(rs.getInt("cod_Producto"));
                nv.setNombre(rs.getString("nombre"));
                nv.setPrecio(rs.getDouble("precio"));
                listarasd.add(nv);
            }
  
        } catch (Exception e) {
     
        }
        return listarasd;
    }
    
    public int guardarVenta(NuevaVenta nvt) {
        String sql = "INSERT INTO pedido (Cod_Empleado, Fecha, Total, Cliente, Comentario) values (?, GETDATE(), ?, ?, ?)";
        try {
            con = cn.getConexion(); // Obtiene la conexión
            ps = con.prepareStatement(sql);
            ps.setInt(1, nvt.getIdemp());
            ps.setDouble(2, nvt.getPrecioto());
            ps.setString(3, nvt.getClit());
            ps.setString(4, nvt.getComenVen());
            a = ps.executeUpdate(); // Inserta la venta y devuelve el número de filas afectadas
        } catch (Exception e) {
            e.printStackTrace(); // Agregar un registro de errores para el diagnóstico
        }
        return a;
    }
    
    public int IdVentas(){
        int id_ped = 0;
        String sql= "select max(Cod_Pedido) from pedido";
            try {
            con = cn.getConexion(); // Obtiene la conexión
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                id_ped=rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id_ped;
        }
    
    public int guardarDetalleventas(NuevaVenta NuevaVenta) {
        String sql = "INSERT INTO detalle_pedido(Cod_Pedido, Cod_Producto, Cantidad, PrecioUnit) VALUES (?, ?, ?, ?)";
        try {
            con = cn.getConexion(); // Obtiene la conexión
            ps = con.prepareStatement(sql);
            ps.setInt(1, NuevaVenta.getCod_ped());
            ps.setInt(2, NuevaVenta.getCod_prod());
            ps.setInt(3, NuevaVenta.getCantidadT());
            ps.setDouble(4, NuevaVenta.getPrecio());
            a = ps.executeUpdate(); // Inserta el detalle del pedido
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return a;
    }
}