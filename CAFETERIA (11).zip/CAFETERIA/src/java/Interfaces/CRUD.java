
package Interfaces;
import Modelo.Ventas;
import Modelo.Inventario;
import Modelo.Producto;
import java.util.List;
public interface CRUD {     
    public List listar();   //MÉTODO CONSUMIDO POR VENTASDAO, LISTA VENTAS EN VENTAS.JSP
    public List listarpr(); //METODO CONSUMIDO POR PRINCIPALDAO, LISTA PRODUCTOS MAS VENDIDOS EN PRINCIPAL.JSP
    public List listarprod(); //Método consumido por ProductoDAO, muestra la lista de productos disponibles en editar-carta.jsp
    public List listarinv();//Método consumido por InventarioDAO, muestra los productos en inventario.jsp
    public List listarNuev(Integer categoriaId); //Método consumido por NuevaVentaDAO, muestra los productos en inventario.jsp
    public List listarusr(); //Método consumido en MostrarUsuarioDAO, utilizado muestra los usuarios en config.jsp
    public boolean eliminar(int id);
    public boolean add(Producto prod);      //MÉTODO PARA agregar un producto
}
